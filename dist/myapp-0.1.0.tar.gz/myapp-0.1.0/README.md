# Flask Calculation API

This Flask app provides a simple API to calculate the sum of two integers.

## Prerequisites

- Python 3.x
- Flask library

Install Flask with:
```bash
pip install Flask
